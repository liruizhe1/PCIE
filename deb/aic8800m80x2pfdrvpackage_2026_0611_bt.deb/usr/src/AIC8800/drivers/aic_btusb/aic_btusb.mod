/home/aic/android_driver/USB/driver_fw/drivers/aic_btusb/aic_btusb.o

