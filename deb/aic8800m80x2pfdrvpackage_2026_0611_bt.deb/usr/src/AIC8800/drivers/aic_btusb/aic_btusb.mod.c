#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x2c635209, "module_layout" },
	{ 0xae2ae519, "param_ops_int" },
	{ 0xe180ce57, "usb_deregister" },
	{ 0x942410fb, "usb_register_driver" },
	{ 0xe2dc6d97, "usb_get_from_anchor" },
	{ 0x3517383e, "register_reboot_notifier" },
	{ 0x9cc4f70a, "register_pm_notifier" },
	{ 0x31b360b9, "hci_register_dev" },
	{ 0x9cfbb611, "usb_driver_claim_interface" },
	{ 0x2aff387f, "usb_ifnum_to_if" },
	{ 0x4b4891f1, "hci_alloc_dev_priv" },
	{ 0xce947466, "usb_disable_autosuspend" },
	{ 0xc3fcadfd, "devm_kmalloc" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x3d7e65af, "usb_control_msg" },
	{ 0x10473ee, "__alloc_skb" },
	{ 0xa3bb6e89, "hci_recv_frame" },
	{ 0x69acdf38, "memcpy" },
	{ 0x28d384c6, "skb_put" },
	{ 0x3398f7af, "usb_set_interface" },
	{ 0x999e8297, "vfree" },
	{ 0x9591a9f, "kernel_read" },
	{ 0xf8c7264e, "filp_close" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x2e1637a6, "kmem_cache_free" },
	{ 0x98303217, "filp_open" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x6c3777ff, "kmem_cache_alloc" },
	{ 0x3096be16, "names_cachep" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x807766ea, "usb_scuttle_anchored_urbs" },
	{ 0x2a8ca7d2, "usb_autopm_put_interface" },
	{ 0xe9de6a72, "usb_autopm_get_interface" },
	{ 0x6cea8936, "__hci_cmd_sync" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x6f72a4bb, "hci_free_dev" },
	{ 0xf621d045, "usb_driver_release_interface" },
	{ 0x25a69299, "hci_unregister_dev" },
	{ 0xac1a55be, "unregister_reboot_notifier" },
	{ 0x7681946c, "unregister_pm_notifier" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x8427cc7b, "_raw_spin_lock_irq" },
	{ 0x962c8ae1, "usb_kill_anchored_urbs" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x2f886acb, "usb_free_urb" },
	{ 0xaf88e69b, "kmem_cache_alloc_trace" },
	{ 0x30a93ed, "kmalloc_caches" },
	{ 0x437b7175, "usb_alloc_urb" },
	{ 0x56baf789, "usb_unanchor_urb" },
	{ 0xb20c3797, "usb_submit_urb" },
	{ 0x6ebe366f, "ktime_get_mono_fast_ns" },
	{ 0x2cf05418, "usb_anchor_urb" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x10bc6bea, "kfree_skb_reason" },
	{ 0x37a0cba, "kfree" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x959ad1ce, "usb_interrupt_msg" },
	{ 0x92997ed8, "_printk" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x71038ac7, "pv_ops" },
};

MODULE_INFO(depends, "bluetooth");

MODULE_ALIAS("usb:vA69Cp8801d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:vA69Cp8D81d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:vA69Cp88DCd*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8D91d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8DA1d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8D45d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8D46d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8D48d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8D49d*dc*dsc*dp*icE0isc01ip01in*");
MODULE_ALIAS("usb:v368Bp8871d*dc*dsc*dp*icE0isc01ip01in*");

MODULE_INFO(srcversion, "78F48CABAE69FE84996608D");
